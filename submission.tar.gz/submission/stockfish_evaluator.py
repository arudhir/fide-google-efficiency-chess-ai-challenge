#!/usr/bin/env python
import chess
import chess.engine
import time
import psutil
from collections import defaultdict
from submission import chess_bot  # Using the correct filename

class StockfishEvaluator:
    def __init__(self, stockfish_path="/usr/games/stockfish"):
        """
        Initialize evaluator with path to Stockfish executable
        stockfish_path: Path to stockfish executable (e.g., "stockfish" if in PATH,
                       or full path like "C:/chess/stockfish.exe")
        """
        self.stockfish_path = stockfish_path
        self.stats = defaultdict(int)
        self.move_times = []
        
    def play_game(self, bot_color=chess.WHITE, opponent_elo=1200):
        """Play a single game against Stockfish at specified ELO"""
        board = chess.Board()
        moves_count = 0
        
        # Initialize Stockfish engine
        engine = chess.engine.SimpleEngine.popen_uci(self.stockfish_path)
        try:
            # Set Stockfish ELO
            engine.configure({"Skill Level": self._elo_to_skill_level(opponent_elo)})
            
            while not board.is_game_over():
                is_bot_turn = (board.turn == bot_color)
                
                if is_bot_turn:
                    # Your bot's move
                    move_start = time.time()
                    observation = {'board': board.fen()}
                    try:
                        move_uci = chess_bot(observation)
                        move = chess.Move.from_uci(move_uci)
                        self.move_times.append(time.time() - move_start)
                        
                        # Record tactical opportunities
                        if board.is_capture(move):
                            self.stats['captures'] += 1
                        if board.gives_check(move):
                            self.stats['checks'] += 1
                            
                    except Exception as e:
                        print(f"Bot error: {e}")
                        self.stats['errors'] += 1
                        break
                else:
                    # Stockfish's move
                    result = engine.play(board, chess.engine.Limit(time=0.1))
                    move = result.move
                
                board.push(move)
                moves_count += 1
                
                # Prevent infinite games
                if moves_count > 200:
                    self.stats['drawn_by_length'] += 1
                    break
                    
        finally:
            engine.quit()
            
        # Record game result
        if board.is_checkmate():
            if board.turn != bot_color:
                self.stats['wins'] += 1
            else:
                self.stats['losses'] += 1
        elif board.is_stalemate():
            self.stats['stalemates'] += 1
        else:
            self.stats['draws'] += 1
            
        self.stats['total_moves'] += moves_count
        
    def _elo_to_skill_level(self, elo):
        """Convert ELO rating to Stockfish skill level (0-20)"""
        # Approximate conversion - can be refined
        min_elo = 1000
        max_elo = 2000
        min_skill = 0
        max_skill = 20
        
        # Clamp ELO to valid range
        elo = max(min_elo, min(max_elo, elo))
        
        # Linear conversion
        skill_level = int((elo - min_elo) * (max_skill - min_skill) / (max_elo - min_elo))
        return skill_level
        
    def run_evaluation(self, num_games=10, opponent_elo=1200):
        """Run multiple games and generate statistics"""
        print(f"Starting evaluation against Stockfish (ELO {opponent_elo})...")
        
        for i in range(num_games):
            # Alternate colors
            bot_color = chess.WHITE if i % 2 == 0 else chess.BLACK
            print(f"Game {i+1}/{num_games} - {'White' if bot_color else 'Black'}")
            self.play_game(bot_color=bot_color, opponent_elo=opponent_elo)
            
        return self.generate_report()
    
    def generate_report(self):
        """Generate a comprehensive evaluation report"""
        total_games = (self.stats['wins'] + self.stats['losses'] + 
                      self.stats['draws'] + self.stats['stalemates'])
        
        if total_games == 0:
            return "No games completed"
            
        report = {
            'performance': {
                'wins': self.stats['wins'],
                'losses': self.stats['losses'],
                'draws': self.stats['draws'] + self.stats['stalemates'],
                'win_rate': self.stats['wins'] / total_games,
                'draw_rate': (self.stats['draws'] + self.stats['stalemates']) / total_games,
                'loss_rate': self.stats['losses'] / total_games,
                'average_game_length': self.stats['total_moves'] / total_games
            },
            'tactics': {
                'captures_per_game': self.stats['captures'] / total_games,
                'checks_per_game': self.stats['checks'] / total_games
            },
            'resource_usage': {
                'average_move_time': sum(self.move_times) / len(self.move_times) if self.move_times else 0,
                'max_move_time': max(self.move_times) if self.move_times else 0
            },
            'reliability': {
                'error_rate': self.stats['errors'] / total_games,
            }
        }
        return report

if __name__ == "__main__":
    from pprint import pprint
    from argparse import ArgumentParser

    parser = ArgumentParser()
    parser.add_argument("--num_games", type=int, default=10)
    parser.add_argument("--elo", type=int, default=1200)
    args = parser.parse_args()

    # evaluator = StockfishEvaluator(stockfish_path="/usr/games/stockfish")
    evaluator = StockfishEvaluator(stockfish_path="/opt/homebrew/bin/stockfish")

    # Run evaluation
    results = evaluator.run_evaluation(num_games=args.num_games, opponent_elo=args.elo)
    pprint(results)
